# Third-party notices

SAIF AI is built on work published by open-source authors. This document names
every third-party library and native runtime component shipped inside the
distributed SAIF AI APK, states its licence, and explains how its obligations
are satisfied. Nothing in `LICENSE` overrides the licences of the third-party
components listed below.


## 1. Copyleft libraries linked by the Android application

| Component | Version | Licence | Relationship & compliance |
|---|---|---|---|
| `io.github.Rosemoe.sora-editor:editor`, `:language-textmate`, `:language-java` | 0.23.6 | **LGPL-2.1** | Linked unmodified from Maven Central as AAR dependencies. Complete Gradle coordinates and build scripts are published at <https://github.com/juwadipro73-svg/Saif> so any user can replace or relink the library, accompanied by `assets/licences/WRITTEN_SOURCE_OFFER.txt`. |

*(Note: `ru.noties:jlatexmath-android` and `io.noties.markwon:ext-latex` were
unused and have been removed from the dependency graph so zero JLaTeXMath
classes or fonts ship in the APK.)*


## 2. Permissive libraries linked by the Android application

| Component | Version | Licence | Role in SAIF AI |
|---|---|---|---|
| `com.github.termux.termux-app:terminal-emulator`, `:terminal-view` | v0.118.1 | **Apache-2.0** (explicitly exempted in `termux-app` `LICENSE.md`) | Native PTY session and interactive terminal view |
| `com.github.mwiede:jsch` | 0.2.20 | **BSD-3-Clause** (+ JZlib BSD, jBCrypt ISC; verbatim notice in `assets/licences/JSCH_LICENSE.txt`) | SSH client library |
| `com.alphacephei:vosk-android` | 0.3.75 | Apache-2.0 | Offline speech recognition (model downloaded on demand) |
| `net.java.dev.jna:jna` | 5.13.0 | Apache-2.0 (dual-licensed LGPL-2.1 / Apache-2.0; elected under Apache-2.0) | Native FFI bridge used by Vosk |
| `org.apache.commons:commons-compress` | 1.26.1 | Apache-2.0 | Tar archive extraction for the Linux rootfs |
| `org.tukaani:xz` | 1.9 | Public Domain (0BSD-equivalent dedication) | XZ stream decompression |
| `org.jsoup:jsoup` | 1.18.3 | MIT | HTML parsing for web tools |
| `io.coil-kt:coil-compose`, `:coil-svg` | 2.7.0 | Apache-2.0 | Image and SVG rendering |
| `com.squareup.okhttp3:okhttp`, `:okhttp-sse` | 4.12.0 | Apache-2.0 | HTTP, WebSocket and SSE networking |
| `com.google.guava:listenablefuture` | 1.0 | Apache-2.0 | Concurrency marker interface |
| AndroidX, Jetpack Compose, Room, WorkManager, Media3, Navigation 3, Security Crypto, WebKit, DataStore, apksig | see `gradle/libs.versions.toml` | Apache-2.0 | Android Jetpack foundation |
| Kotlin stdlib, `kotlinx.coroutines`, `kotlinx.serialization` | see `gradle/libs.versions.toml` | Apache-2.0 | Language runtime and serialization |
| Firebase (`firebase-auth`, `firebase-firestore`, `firebase-database`, `firebase-appcheck-playintegrity`) | see `gradle/libs.versions.toml` | Apache-2.0 / Google APIs Terms | Authentication and cloud sync |

### Note on Termux `terminal-emulator` and `terminal-view`

Although the top-level `termux/termux-app` application is licensed under
GPL-3.0-only, its `LICENSE.md` **Exceptions** section explicitly states that
the `terminal-emulator` and `terminal-view` library modules are licensed under
the **Apache License 2.0** (descending from Jack Palevich's Apache-2.0
`Android-Terminal-Emulator`). SAIF AI depends solely on `terminal-emulator` and
`terminal-view` and does **not** include `termux-shared` or `:app`, so zero
GPL-3.0 code enters the APK.


## 3. Standalone native executables & runtime archives in the APK

Android's `W^X` security policy forbids executing binaries directly from
writable app data directories (`filesDir`) on modern Android releases, while
binaries unpacked by PackageManager from `lib/<abi>/lib*.so` into
`nativeLibraryDir` reside on an `exec`-mounted filesystem. Accordingly, the
standalone Linux user-space tools below are packaged in `assets/` and mirrored
into `lib/arm64-v8a/`:

| File(s) in APK | Upstream Project | Licence | Packaging & Process Boundary |
|---|---|---|---|
| `assets/bin/proot`, `assets/bin/loader`, `lib/arm64-v8a/libproot.so`, `lib/arm64-v8a/libprootloader.so` | Termux PRoot (<https://github.com/termux/proot>) | **GPL-2.0-or-later** | Standalone user-space executables invoked exclusively via `execvp` / `ProcessBuilder` across an OS process boundary (**mere aggregation** under GPL-2.0 §2). Guest processes strip `LD_LIBRARY_PATH` and `LD_PRELOAD` via `/usr/bin/env -u`. |
| `assets/bin/libtalloc.so.2`, `assets/lib/libtalloc.so.2`, `lib/arm64-v8a/libtalloc.so` | Samba talloc (<https://git.samba.org/?p=samba.git;a=tree;f=lib/talloc>) | **LGPL-3.0-or-later** | Unmodified dynamic shared library loaded solely by the standalone `proot` process, never linked into the SAIF AI JVM/ART process. |
| `assets/glibc-min-arm64.tar` | GNU C Library (<https://sourceware.org/git/glibc.git>) | **LGPL-2.1-or-later** (with GCC/glibc runtime exception) | Unmodified shared libraries unpacked only inside the isolated guest Linux environment. |
| `lib/arm64-v8a/libsaifdaemon.so` | SAIF AI `termux-daemon/server.go` + Go stdlib (<https://go.dev/LICENSE>) | **SAIF AI (`LICENSE`) + Go BSD-3-Clause** | Clean-room Go workspace HTTP daemon written from scratch for SAIF AI using only the BSD-3-Clause Go standard library. |

### Debian 13 ("Trixie") root filesystem — downloaded at runtime

SAIF AI does **not** bundle a Debian rootfs inside the APK. On first terminal
use, `LocalEnvironmentManager` downloads `debian-trixie-aarch64-pd-v4.29.0.tar.xz`
(or `x86_64`) from <https://github.com/termux/proot-distro/releases/tag/v4.29.0>
into `filesDir/usr`. Every package inside that Debian rootfs retains its own
DFSG-compliant upstream licence documented in `/usr/share/doc/*/copyright`.

### Bundled verbatim notices & three-year written source offer

- `assets/legal/LICENSE` — SAIF AI software licence
- `assets/legal/THIRD_PARTY_NOTICES.md` — this complete third-party inventory
- `assets/licences/JSCH_LICENSE.txt` — verbatim JSch 0.2.20 3-clause BSD, JZlib BSD, and jBCrypt ISC licence text
- `assets/licences/WRITTEN_SOURCE_OFFER.txt` — three-year written offer for the Corresponding Source of `proot`, `libtalloc`, `glibc-min-arm64.tar`, and `sora-editor` under GPL-2.0 §3(b), LGPL-2.1 §6(b), and LGPL-3.0 §4


## 4. Measured provenance summary

Reproducible with:

```bash
git clone --depth 1 https://github.com/Santoshkurmi/antigem.git /tmp/upstream-antigem
python3 tools/licence/provenance.py --upstream /tmp/upstream-antigem --write
python3 tools/licence/add_saif_headers.py
```

| Metric | Count |
|---|---|
| Scanned source & script files (including extensionless scripts) | **426** |
| Original SAIF AI files (never existed upstream) | **408** |
| Shared Android / Gradle / root paths | **18** |
| — Identical to upstream (`>= 0.95`) | **0** (0 lines) |
| — Modified from upstream (`0.60 – 0.95`) | **0** (0 lines) |
| — Renamed verbatim copies | **0** |
| Highest similarity on any shared path | **0.455** (`ic_launcher.xml`, 9-line Android adaptive-icon XML) |
